请大家查阅网络资源（如NCBI和ENSEMBL）以及文献等资料回答以下问题:

1) 人类基因组的大小以及基本组成是哪些？

    人类基因组大小为3,099,750,718个碱基对，
    
    GRCh38.p14 (Genome Reference Consortium Human Build 38), INSDC Assembly GCA_000001405.29, Dec 2013这一Assembly的数据量为contig length total 3.4 Gb & chromosome length total 3.1 Gb (excluding haplotypes).

    其基本组成包括：rRNA, mRNA, tRNA, snRNA, snoRNA, misc-srpRNA, misc-Y RNA, misc-other RNA, pesudogene, lncRNA, TUCP, miRNA, piRNA, circRNA, promoter, enhancer, intron, exon, transposable elements.

2) 基因中的非编码RNA的最新注释是多少个了？请详细列一下其中的非编码RNA的细分类型的数目，并对主要的非编码RNA是什么做的用1-2句解释一下。

